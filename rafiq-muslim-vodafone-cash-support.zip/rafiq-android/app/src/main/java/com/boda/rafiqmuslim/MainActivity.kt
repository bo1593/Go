package com.boda.rafiqmuslim

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import android.widget.LinearLayout
import android.view.View
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import org.json.JSONObject
import java.util.Calendar

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestRuntimePermissions()
        askExactAlarmPermissionIfNeeded()
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webChromeClient = WebChromeClient()
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url) ?: super.shouldInterceptRequest(view, request)
            }
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        web.addJavascriptInterface(PrayerBridge(this), "AndroidPrayer")
        root.addView(web, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT))
        setContentView(root)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun requestRuntimePermissions() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 41)
        }
    }

    private fun askExactAlarmPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (!am.canScheduleExactAlarms()) {
                try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } catch (_: Exception) { }
            }
        }
    }


    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}

class PrayerBridge(private val context: Context) {
    @JavascriptInterface
    fun setPrayerTimes(json: String) {
        try {
            val obj = JSONObject(json)
            val names = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")
            val prefs = context.getSharedPreferences("prayer_schedule", Context.MODE_PRIVATE)
            prefs.edit().putString("times", json).apply()
            val now = Calendar.getInstance()
            val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            names.forEachIndexed { index, name ->
                val raw = obj.optString(name, "")
                val parts = raw.split(":")
                if (parts.size != 2) return@forEachIndexed
                val hour = parts[0].toIntOrNull() ?: return@forEachIndexed
                val minute = parts[1].toIntOrNull() ?: return@forEachIndexed
                val whenAt = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, minute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
                }
                val intent = Intent(context, PrayerAlarmReceiver::class.java).apply {
                    putExtra("prayer", name)
                    action = "com.boda.rafiqmuslim.PRAYER_$name"
                }
                val pi = android.app.PendingIntent.getBroadcast(context, index + 100, intent,
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
                if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenAt.timeInMillis, pi)
                else am.setExact(AlarmManager.RTC_WAKEUP, whenAt.timeInMillis, pi)
            }
        } catch (_: Exception) { }
    }
}
