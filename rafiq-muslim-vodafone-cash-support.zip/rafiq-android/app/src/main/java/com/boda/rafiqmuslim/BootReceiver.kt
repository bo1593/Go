package com.boda.rafiqmuslim

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import org.json.JSONObject

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val json = context.getSharedPreferences("prayer_schedule", Context.MODE_PRIVATE).getString("times", null) ?: return
        PrayerBridge(context).setPrayerTimes(json)
    }
}
