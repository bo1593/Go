// تشغيل محليًا على جهاز المطور فقط بعد تثبيت firebase-admin.
// لا ترفع ملف Service Account أو هذا السكربت إلى استضافة عامة أو داخل APK.
const admin = require('firebase-admin');
const serviceAccount = require('./service-account.json');
const uid = process.argv[2];
if (!uid) throw new Error('Usage: node set-admin-claim.js FIREBASE_AUTH_UID');
admin.initializeApp({ credential: admin.credential.cert(serviceAccount) });
admin.auth().setCustomUserClaims(uid, { admin: true })
  .then(() => { console.log('Admin claim set. Sign out and sign in again.'); process.exit(0); })
  .catch(e => { console.error(e); process.exit(1); });
